var nome, cognome, addBtn, elencoHTML, errore, erroreElenco, elenco = [];

window.addEventListener('DOMContentLoaded', init);

function init() {
	nome = document.getElementById('nome');
	cognome = document.getElementById('cognome');
	addBtn = document.getElementById('scrivi');
	elencoHTML = document.getElementById('elenco');
	errore = document.getElementById('errore');
	erroreElenco = document.getElementById('erroreElenco');
	printData();
}

printData = () => {
	fetch('http://localhost:3000/elenco')
		.then((response) => {
			return response.json();
		})
		.then((data) => {
			elenco = data;
			if (elenco.length > 0) {
				errore.innerHTML = '';
				elencoHTML.innerHTML = '';
				elenco.map(function (element) {
					elencoHTML.innerHTML += `<li class="list-unstyled"><button type="button" class="btn btn-danger me-2" onClick="elimina(${element.id})"><i class="fa-solid fa-trash-can"></i></button><button type="button" class="btn btn-success m-2" onClick="modifica(${element.id})"><i class="fa-solid fa-pen-to-square"></i></button>${element.cognome} ${element.nome}</li>`;
				});
			} else {
				erroreElenco.innerHTML = 'Nessun elemento presente in elenco';
			}
		});
}

controlla = () => {
	if (nome.value != '' && cognome.value != '') {
		var data = {
			nome: nome.value,
			cognome: cognome.value,
		};
		addData(data);
	} else {
		errore.innerHTML = 'Compilare correttamente i campi!';
		return;
	}
}
// POST --------------------------------------------
async function addData(data) {
	let response = await fetch('http://localhost:3000/elenco', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json;charset=utf-8',
		},
		body: JSON.stringify(data),
	});
	clearForm();
}

clearForm = () => {
	nome.value = '';
	cognome.value = '';
}
// DELETE --------------------------------------------
elimina = (n) => {
	var answer = window.confirm("Sei sicuro di voler eliminare l'elemento?");
	if (answer) {
		fetch('http://localhost:3000/elenco/' + n, {
			method: 'DELETE',
		});
	};
}

// PUT --------------------------------------------
modifica = (n) => {
	addBtn.setAttribute("onclick", "put(" + n + ")");
	fetch('http://localhost:3000/elenco/' + n)
		.then((response) => {
			return response.json();
		})
		.then((data) => {
			nome.value = data.nome;
			cognome.value = data.cognome;
		});
}

put = (n) => {
	if (nome.value != '' && cognome.value != '') {
		addBtn.setAttribute("onclick", "controlla()");
		var data = {
			nome: nome.value,
			cognome: cognome.value,
		};
		modData(n, data);
	} else {
		errore.innerHTML = 'Compilare correttamente i campi!';
		return;
	}
}

async function modData(n, data) {
	let response = await fetch('http://localhost:3000/elenco/' + n, {
		method: 'PUT',
		headers: {
			'Content-Type': 'application/json;charset=utf-8',
		},
		body: JSON.stringify(data),
	});
	clearForm();
}